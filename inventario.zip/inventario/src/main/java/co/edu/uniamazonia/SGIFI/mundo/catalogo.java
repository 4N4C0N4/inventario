/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

import java.util.ArrayList;
import java.util.List;
public class catalogo {

    private List<Producto> listaProductos;

    public catalogo() {
        listaProductos = new ArrayList<>();
        listaProductos.add(new Producto("laptop", "001", 75000));
        listaProductos.add(new Producto("mouse", "002", 25000));
        listaProductos.add(new Producto("arroz", "003",2000));
        listaProductos.add(new Producto("frigoles", "004",2500));
        listaProductos.add(new Producto("raton", "005",50000));   
    }

    public void agregarProducto(Producto p) {
        listaProductos.add(p);
    }

    public void mostrarCatalogo() {
        System.out.println("--- CATÁLOGO DE PRODUCTOS ---");
        for (Producto p : listaProductos) {
            p.mostrarDetalles();
        }
    }

    public boolean eliminarProducto(String idBuscado){
        for (int i = 0; i < listaProductos.size(); i++) {
            if (listaProductos.get(i).darId().equalsIgnoreCase(idBuscado))         {
                 listaProductos.remove(i);
                return true;
            } 
            
        }
        return false;
    }
}



