/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

/**
 *
 * @author isnel
 */
public class Producto {
  private String nombre;
  private String id;
  private int preciou;
  private int cantidad;  

    public Producto(String nombre, String id, int preciou, int cantidad) {
        this.nombre = nombre;
        this.id = id;
        this.preciou = preciou;
        this.cantidad = cantidad;
    }
  public String darNombre(){
       return this.nombre;
      
  }
  public String darId(){
      return this.id;
  }
  public int darPreciou(){
      return this.preciou;
  }
  public int darCantiad(){
      return this.cantidad;
  }
  public void mostrarDetalles(){
      System.out.println("nombre: " + nombre + "\nid: " + id + "\nPrecio Unitario: " + preciou + "\nCantidad: " + cantidad);
  }
}
