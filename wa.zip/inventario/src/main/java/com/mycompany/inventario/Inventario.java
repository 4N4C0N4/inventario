/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inventario;

import java.util.Scanner;

/**
 *
 * @author isnel
 */
// objetivos
//agregar producto, eleminar producto, factuar,
public class Inventario {

    public static void main(String[] args) {
      Scanner x = new Scanner(System.in);
       catalogo listav = new catalogo();
        
        listav.agregarProducto(new Producto("laptop", "001", 750, 5));
        listav.agregarProducto(new Producto("mouse", "002", 25, 15));
        x.nextLine();
        String opcion1 = "s";
        while(opcion1.equalsIgnoreCase("s")){
             System.out.println("Que desea hacer: " + "\n1-Agregar producto" + "\n2-Eliminar producto" + "\n3-facturar" );
        int opcion2 = x.nextInt();
        switch(opcion2){
            case 1:
                System.out.println("Nombre del producto");
                String nombrepn = x.nextLine();
                System.out.println("Id del producto");
                String idpn = x.nextLine();
                System.out.println("Precio unitario del producto");
                int precioupn = x.nextInt();
                System.out.println("cantidad del producto;");
                int cantidadpn = x.nextInt();
                x.nextLine();
                listav.agregarProducto(new Producto(nombrepn, idpn, precioupn, cantidadpn));
                System.out.println("Producto agregado");
                System.out.println("desea hace otra accion: S/N");
                opcion1 = x.nextLine();
                listav.mostrarCatalogo();
                
            case 2:
                
            case 3:
                
        }
        }
        listav.mostrarCatalogo();
    }
}
