/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

/**
 *
 * @author isnel
 */
public class DetalleFactura {
        private int cantidad;
    private double precioUnitario;
    private Factura factura;

    public DetalleFactura(int cantidad, double precioUnitario) {
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public int DarCantidad() {
        return this.cantidad;
    }

    public double DarPrecioUnitario() {
        return this.precioUnitario;
    }
    

    
    
    
}

