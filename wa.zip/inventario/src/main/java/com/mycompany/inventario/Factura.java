/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

/**
 *
 * @author isnel
 */
public class Factura {
      private int numero;
    private String fecha;
    

    public Factura(int numero, String fecha) {
        this.numero = numero;
        this.fecha = fecha;
    }
    
           
}

