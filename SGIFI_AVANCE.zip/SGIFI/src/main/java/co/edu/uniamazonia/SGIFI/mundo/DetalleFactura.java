/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;


/**
 * Un renglón de la factura: una cantidad de un producto.
 *
 * @author isnel
 */
public class DetalleFactura {

    private int cantidad;
    private double subtotal;

    // Asociación simple hacia Producto (atributo de tipo objeto)
    private Producto producto;

    public DetalleFactura(int cantidad, Producto producto) {
        this.cantidad = cantidad;
        this.producto = producto;
        this.subtotal = calcularSubtotal();
    }

    /**
     * Calcula el subtotal multiplicando la cantidad por el precio unitario del producto.
     */
    public double calcularSubtotal() {
        if (this.producto != null) {
            this.subtotal = this.cantidad * this.producto.darPrecioUnitario();
        } else {
            this.subtotal = 0.0;
        }
        return this.subtotal;
    }

    public int darCantidad() {
        return this.cantidad;
    }

    public double darSubtotal() {
        return this.subtotal;
    }

    public Producto darProducto() {
        return this.producto;
    }
}
    
    


