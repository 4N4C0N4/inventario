/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * El dueño del sistema: tiene todos los permisos y no se le pueden quitar.
 */
public class Administrador extends Usuario {

    public Administrador(String nombre, String nombreUsuario, String contrasena) {
        super(nombre, nombreUsuario, contrasena);
        for (Permiso p : Permiso.values()) {
            otorgarPermiso(p);
        }
    }

    @Override
    public String darRol() {
        return "Administrador";
    }

    @Override
    public boolean puedeRecibir(Permiso permiso) {
        return true;
    }

    @Override
    public boolean revocarPermiso(Permiso permiso) {
        return false;
    }
}