/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Lista de acciones que un usuario puede tener permitidas.
 * Un enum es una clase especial con un conjunto fijo de valores.
 */
public enum Permiso {

    VER_CATALOGO("Ver el catálogo de productos"),
    CONSULTAR_PRODUCTO("Consultar un producto por su nombre"),
    AGREGAR_PRODUCTO("Agregar productos o sumar stock"),
    ELIMINAR_PRODUCTO("Eliminar productos"),
    FACTURAR("Hacer facturas"),
    VER_FABRICANTE("Ver el fabricante de los productos"),
    REGISTRAR_CLIENTE("Registrar clientes nuevos"),
    GESTIONAR_USUARIOS("Registrar usuarios y gestionar permisos");

    private String descripcion;

    private Permiso(String descripcion) {
        this.descripcion = descripcion;
    }

    public String darDescripcion() {
        return this.descripcion;
    }
}