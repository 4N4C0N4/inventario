/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Empresa que fabrica uno o varios productos.
 */
public class Fabricante {

    private String nombre;
    private String pais;
    private String contacto;

    public Fabricante(String nombre, String pais, String contacto) {
        this.nombre = nombre;
        this.pais = pais;
        this.contacto = contacto;
    }

    public String darNombre() {
        return this.nombre;
    }

    public String darPais() {
        return this.pais;
    }

    public String darContacto() {
        return this.contacto;
    }

    public String darDescripcion() {
        return "Fabricante: " + this.nombre + "\nPaís: " + this.pais + "\nContacto: " + this.contacto + "\n";
    }
}