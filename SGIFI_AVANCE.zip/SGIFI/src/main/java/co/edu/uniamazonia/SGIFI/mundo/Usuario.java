/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

import java.util.ArrayList;

/**
 * Clase base de todas las personas que inician sesión.
 * Es abstracta: no se crean "Usuario" a secas, sino Administrador, Trabajador o Cliente.
 * Cada usuario guarda su propia lista de permisos, que el administrador puede modificar.
 */
public abstract class Usuario {

    private String nombre;
    private String nombreUsuario;
    private String contrasena;
    private ArrayList<Permiso> permisos;

    public Usuario(String nombre, String nombreUsuario, String contrasena) {
        this.nombre = nombre;
        this.nombreUsuario = nombreUsuario;
        this.contrasena = contrasena;
        this.permisos = new ArrayList<Permiso>();
    }

    public String darNombre() {
        return this.nombre;
    }

    public String darNombreUsuario() {
        return this.nombreUsuario;
    }

    public boolean validarContrasena(String intento) {
        return this.contrasena.equals(intento);
    }

    /**
     * Cambia la contraseña solo si la actual es correcta y la nueva no está vacía.
     */
    public boolean cambiarContrasena(String actual, String nueva) {
        if (validarContrasena(actual) && !nueva.isEmpty()) {
            this.contrasena = nueva;
            return true;
        }
        return false;
    }

    public boolean tienePermiso(Permiso permiso) {
        return this.permisos.contains(permiso);
    }

    /**
     * Indica si este tipo de usuario puede recibir el permiso.
     * Por defecto, el permiso de gestionar usuarios está reservado al administrador,
     * para que nadie pueda darse poder de administrador a sí mismo.
     */
    public boolean puedeRecibir(Permiso permiso) {
        return permiso != Permiso.GESTIONAR_USUARIOS;
    }

    /**
     * Otorga un permiso.
     * @return true si el usuario queda con el permiso, false si no puede recibirlo.
     */
    public boolean otorgarPermiso(Permiso permiso) {
        if (!puedeRecibir(permiso)) {
            return false;
        }
        if (!this.permisos.contains(permiso)) {
            this.permisos.add(permiso);
        }
        return true;
    }

    /**
     * Quita un permiso.
     * @return true si se quitó, false si no lo tenía o no se puede quitar.
     */
    public boolean revocarPermiso(Permiso permiso) {
        return this.permisos.remove(permiso);
    }

    public String listarPermisos() {
        if (this.permisos.isEmpty()) {
            return "(ninguno)";
        }
        String texto = "";
        for (int i = 0; i < this.permisos.size(); i++) {
            texto += this.permisos.get(i).darDescripcion();
            if (i < this.permisos.size() - 1) {
                texto += ", ";
            }
        }
        return texto;
    }

    /**
     * Cada subclase dice cuál es su rol (polimorfismo).
     */
    public abstract String darRol();
}