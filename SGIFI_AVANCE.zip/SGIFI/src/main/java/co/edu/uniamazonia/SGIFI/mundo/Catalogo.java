/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

import java.util.ArrayList;
import java.util.List;

/**
 * Guarda los productos del inventario y se encarga de generar sus códigos.
 */
public class Catalogo {

    private List<Producto> listaProductos;

    // Último número usado para generar códigos (p001, p002...).
    // Nunca baja, aunque se elimine un producto, así un código no se reutiliza.
    private int contadorId;

    public Catalogo() {
        listaProductos = new ArrayList<>();
        contadorId = 0;

        // Datos de ejemplo (fabricantes inventados, cámbialos por los reales)
        Fabricante tecnoSur = new Fabricante("TecnoSur", "Colombia", "ventas@tecnosur.com");
        Fabricante andina = new Fabricante("Comercial Andina", "Colombia", "contacto@andina.com");
        Fabricante agro = new Fabricante("Agroamazonia", "Colombia", "info@agroamazonia.com");

        agregarProducto("laptop", 75000, 10, tecnoSur);
        agregarProducto("mouse", 25000, 15, andina);
        agregarProducto("arroz", 2000, 50, agro);
        agregarProducto("frijoles", 2500, 40, agro);
        agregarProducto("raton", 50000, 8, tecnoSur);
    }

    /**
     * Crea un producto con un código nuevo generado automáticamente y lo agrega.
     * @return el producto recién creado (para poder informar su código).
     */
    public Producto agregarProducto(String nombre, int precioUnitario, int cantidad, Fabricante fabricante) {
        Producto nuevo = new Producto(nombre, generarId(), precioUnitario, cantidad, fabricante);
        listaProductos.add(nuevo);
        return nuevo;
    }

    private String generarId() {
        contadorId++;
        return String.format("p%03d", contadorId);
    }

    public Producto buscarPorId(String idBuscado) {
        for (Producto p : listaProductos) {
            if (p.darId().equalsIgnoreCase(idBuscado.trim())) {
                return p;
            }
        }
        return null;
    }

    /**
     * Búsqueda exacta por nombre (sin importar mayúsculas). Sirve para detectar duplicados.
     */
    public Producto buscarPorNombre(String nombreBuscado) {
        for (Producto p : listaProductos) {
            if (p.darNombre().equalsIgnoreCase(nombreBuscado.trim())) {
                return p;
            }
        }
        return null;
    }

    /**
     * Búsqueda por parte del nombre: "lap" encuentra "laptop".
     * @return la lista de productos que coinciden (vacía si no hay ninguno).
     */
    public List<Producto> buscarPorTexto(String texto) {
        List<Producto> resultados = new ArrayList<>();
        String buscado = texto.trim().toLowerCase();
        for (Producto p : listaProductos) {
            if (p.darNombre().toLowerCase().contains(buscado)) {
                resultados.add(p);
            }
        }
        return resultados;
    }

    /**
     * Busca un fabricante ya existente entre los productos, para reutilizarlo
     * en vez de crear uno repetido.
     */
    public Fabricante buscarFabricante(String nombreFabricante) {
        for (Producto p : listaProductos) {
            if (p.darFabricante().darNombre().equalsIgnoreCase(nombreFabricante.trim())) {
                return p.darFabricante();
            }
        }
        return null;
    }

    public boolean eliminarProducto(String idBuscado) {
        Producto p = buscarPorId(idBuscado);
        if (p != null) {
            listaProductos.remove(p);
            return true;
        }
        return false;
    }

    /**
     * Devuelve el catálogo como texto (no imprime nada; imprime quien lo llame).
     */
    public String listarCatalogo(boolean conFabricante) {
        String texto = "--- CATÁLOGO DE PRODUCTOS ---\n";
        if (listaProductos.isEmpty()) {
            return texto + "(no hay productos)\n";
        }
        for (Producto p : listaProductos) {
            texto += p.darDescripcion(conFabricante) + "\n";
        }
        return texto;
    }
}