/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Pago con tarjeta. Solo se guardan el tipo y los últimos 4 dígitos,
 * nunca el número completo.
 */
public class Tarjeta extends MetodoPago {

    private String tipo;
    private String ultimosDigitos;

    public Tarjeta(String tipo, String ultimosDigitos) {
        super("Tarjeta");
        this.tipo = tipo;
        this.ultimosDigitos = ultimosDigitos;
    }

    @Override
    public boolean cubreTotal(double total) {
        return true;
    }

    @Override
    public String describir(double total) {
        return "Método de pago: Tarjeta " + this.tipo + " (terminada en " + this.ultimosDigitos + ")\n";
    }
}