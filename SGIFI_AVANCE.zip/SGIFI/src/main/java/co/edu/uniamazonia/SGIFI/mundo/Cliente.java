/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Cliente: es un usuario que puede consultar el catálogo y los productos,
 * y también la persona a la que se le emite una factura.
 */
public class Cliente extends Usuario {

    private String identificacion;
    private String correo;

    public Cliente(String nombre, String identificacion, String correo,
                   String nombreUsuario, String contrasena) {
        super(nombre, nombreUsuario, contrasena);
        this.identificacion = identificacion;
        this.correo = correo;
        otorgarPermiso(Permiso.VER_CATALOGO);
        otorgarPermiso(Permiso.CONSULTAR_PRODUCTO);
    }

    public String darIdentificacion() {
        return this.identificacion;
    }

    public String darCorreo() {
        return this.correo;
    }

    @Override
    public String darRol() {
        return "Cliente";
    }
}