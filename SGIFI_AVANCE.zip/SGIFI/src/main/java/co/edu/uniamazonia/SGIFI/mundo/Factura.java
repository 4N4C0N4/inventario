/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

import java.util.ArrayList;

/**
 * Factura emitida a un cliente, formada por varios renglones (DetalleFactura),
 * con el usuario que la atendió y el método de pago.
 *
 * @author isnel
 */
public class Factura {

    private int numeroFactura;
    private String fecha;
    private double total;

    private Cliente cliente;
    private Usuario vendedor;
    private MetodoPago metodoPago;
    private ArrayList<DetalleFactura> detalles;

    public Factura(int numeroFactura, String fecha, Cliente cliente, Usuario vendedor) {
        this.numeroFactura = numeroFactura;
        this.fecha = fecha;
        this.cliente = cliente;
        this.vendedor = vendedor;
        this.metodoPago = null;
        this.detalles = new ArrayList<DetalleFactura>();
        this.total = 0.0;
    }

    public void agregarDetalle(DetalleFactura detalle) {
        if (detalle != null) {
            this.detalles.add(detalle);
        }
    }

    public double calcularTotal() {
        double acumulado = 0.0;
        for (int i = 0; i < this.detalles.size(); i++) {
            DetalleFactura det = this.detalles.get(i);
            acumulado += det.calcularSubtotal();
        }
        this.total = acumulado;
        return this.total;
    }

    /**
     * Cuenta cuántas unidades de un producto ya están en esta factura.
     */
    public int cantidadFacturada(Producto producto) {
        int suma = 0;
        for (DetalleFactura det : this.detalles) {
            if (det.darProducto() == producto) {
                suma += det.darCantidad();
            }
        }
        return suma;
    }

    /**
     * Guarda el método de pago solo si cubre el total de la factura.
     * @return true si quedó registrado, false si el pago no alcanza.
     */
    public boolean registrarPago(MetodoPago pago) {
        if (pago != null && pago.cubreTotal(calcularTotal())) {
            this.metodoPago = pago;
            return true;
        }
        return false;
    }

    /**
     * Descuenta del stock de cada producto las unidades facturadas.
     * Se llama una sola vez, cuando la factura ya quedó confirmada y pagada.
     */
    public void descontarInventario() {
        for (DetalleFactura det : this.detalles) {
            det.darProducto().retirarCantidad(det.darCantidad());
        }
    }

    public boolean estaVacia() {
        return this.detalles.isEmpty();
    }

    public String generarResumen() {
        String texto = "Factura N: " + this.numeroFactura + "\n"
                + "Fecha: " + this.fecha + "\n"
                + "Atendió: " + this.vendedor.darNombre() + "\n"
                + "Cliente: " + this.cliente.darNombre() + " (" + this.cliente.darIdentificacion() + ")\n";
        for (DetalleFactura det : this.detalles) {
            texto += det.darCantidad() + " x " + det.darProducto().darNombre()
                    + " - $" + det.darSubtotal() + "\n";
        }
        double totalFactura = calcularTotal();
        texto += "Total a pagar: $" + totalFactura + "\n";
        if (this.metodoPago != null) {
            texto += this.metodoPago.describir(totalFactura);
        }
        return texto;
    }

    public int darNumeroFactura() {
        return this.numeroFactura;
    }

    public String darFecha() {
        return this.fecha;
    }

    public Cliente darCliente() {
        return this.cliente;
    }

    public Usuario darVendedor() {
        return this.vendedor;
    }

    public MetodoPago darMetodoPago() {
        return this.metodoPago;
    }

    public ArrayList<DetalleFactura> darDetalles() {
        return this.detalles;
    }
}