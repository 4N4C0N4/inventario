/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Representa un producto del inventario.
 * El stock (cantidad) solo se modifica mediante los métodos de la clase,
 * así nunca puede quedar en negativo.
 *
 * @author isnel
 */
public class Producto {

    private String nombre;
    private String id;
    private int precioUnitario;
    private int cantidad;

    // Asociación hacia Fabricante: varios productos pueden tener el mismo fabricante
    private Fabricante fabricante;

    public Producto(String nombre, String id, int precioUnitario, int cantidad, Fabricante fabricante) {
        this.nombre = nombre;
        this.id = id;
        this.precioUnitario = precioUnitario;
        this.cantidad = cantidad;
        this.fabricante = fabricante;
    }

    public String darNombre() {
        return this.nombre;
    }

    public String darId() {
        return this.id;
    }

    public int darPrecioUnitario() {
        return this.precioUnitario;
    }

    public int darCantidad() {
        return this.cantidad;
    }

    public Fabricante darFabricante() {
        return this.fabricante;
    }

    /**
     * Suma unidades al stock. Ignora valores que no sean positivos.
     */
    public void agregarCantidad(int unidades) {
        if (unidades > 0) {
            this.cantidad += unidades;
        }
    }

    /**
     * Indica si hay suficientes unidades para retirar la cantidad pedida.
     */
    public boolean hayStock(int unidades) {
        return unidades > 0 && unidades <= this.cantidad;
    }

    /**
     * Resta unidades al stock solo si alcanzan.
     * @return true si se pudo retirar, false si no había suficiente stock.
     */
    public boolean retirarCantidad(int unidades) {
        if (hayStock(unidades)) {
            this.cantidad -= unidades;
            return true;
        }
        return false;
    }

    /**
     * Una línea de texto para las listas. El fabricante solo se incluye si quien
     * mira tiene permiso para verlo (lo decide quien llama, no el producto).
     */
    public String darDescripcion(boolean conFabricante) {
        String texto = this.id + " | " + this.nombre + " | $" + this.precioUnitario
                + " | Stock: " + this.cantidad;
        if (conFabricante) {
            texto += " | Fabricante: " + this.fabricante.darNombre();
        }
        return texto;
    }

    /**
     * Toda la información del producto, en varias líneas.
     */
    public String darFicha(boolean conFabricante) {
        String texto = "Código: " + this.id
                + "\nNombre: " + this.nombre
                + "\nPrecio unitario: $" + this.precioUnitario
                + "\nUnidades disponibles: " + this.cantidad;
        if (this.cantidad == 0) {
            texto += " (agotado)";
        }
        if (conFabricante) {
            texto += "\nFabricante: " + this.fabricante.darNombre();
        }
        return texto + "\n";
    }
}