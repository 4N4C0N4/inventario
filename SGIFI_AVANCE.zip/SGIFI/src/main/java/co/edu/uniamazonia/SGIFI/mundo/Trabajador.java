/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Empleado: ve el catálogo, consulta productos, factura y registra clientes.
 * El administrador puede darle permisos adicionales o quitárselos.
 */
public class Trabajador extends Usuario {

    public Trabajador(String nombre, String nombreUsuario, String contrasena) {
        super(nombre, nombreUsuario, contrasena);
        otorgarPermiso(Permiso.VER_CATALOGO);
        otorgarPermiso(Permiso.CONSULTAR_PRODUCTO);
        otorgarPermiso(Permiso.FACTURAR);
        otorgarPermiso(Permiso.REGISTRAR_CLIENTE);
    }

    @Override
    public String darRol() {
        return "Trabajador";
    }
}