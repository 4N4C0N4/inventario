/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package co.edu.uniamazonia.SGIFI.mundo;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

/**
 * Clase principal: solo lee datos y muestra mensajes.
 * Las reglas viven en las demás clases (Usuario y sus subclases, Catalogo, Factura...).
 *
 * @author isnel
 */
public class SGIFI {

    // Texto o número que el operador escribe para cancelar la acción en curso
    private static final String CANCELAR = "0";
    private static final int MAX_INTENTOS = 3;

    // Número de la próxima factura; sube cada vez que se emite una
    private static int numeroFactura = 1001;

    public static void main(String[] args) {
        Scanner x = new Scanner(System.in);
        Catalogo catalogo = new Catalogo();
        GestorUsuarios gestor = new GestorUsuarios();

        boolean sistemaActivo = true;
        while (sistemaActivo) {
            Usuario usuario = iniciarSesion(x, gestor);
            if (usuario == null) {
                sistemaActivo = false;
            } else {
                atenderSesion(x, catalogo, gestor, usuario);
            }
        }
        System.out.println("Hasta luego.");
    }

    // ---------------------------------------------------------------
    // Inicio de sesión y menú
    // ---------------------------------------------------------------

    /**
     * @return el usuario que inició sesión, o null si se quiere salir del sistema
     *         (escribiendo 0 o tras demasiados intentos fallidos).
     */
    private static Usuario iniciarSesion(Scanner x, GestorUsuarios gestor) {
        System.out.println();
        System.out.println("====== SGIFI - INICIAR SESIÓN (escriba 0 para salir del sistema) ======");
        for (int intento = 1; intento <= MAX_INTENTOS; intento++) {
            String nombreUsuario = leerTexto(x, "Usuario: ");
            if (nombreUsuario.equals(CANCELAR)) {
                return null;
            }
            String contrasena = leerTexto(x, "Contraseña: ");
            Usuario usuario = gestor.iniciarSesion(nombreUsuario, contrasena);
            if (usuario != null) {
                return usuario;
            }
            System.out.println("Usuario o contraseña incorrectos (intento " + intento + " de " + MAX_INTENTOS + ").");
        }
        System.out.println("Demasiados intentos fallidos.");
        return null;
    }

    private static void atenderSesion(Scanner x, Catalogo catalogo, GestorUsuarios gestor, Usuario usuario) {
        boolean sesionActiva = true;
        while (sesionActiva) {
            System.out.println();
            System.out.println("Sesión: " + usuario.darNombre() + " (" + usuario.darRol() + ")");

            // El catálogo se muestra siempre, sin elegir opción, si el usuario tiene permiso
            if (usuario.tienePermiso(Permiso.VER_CATALOGO)) {
                System.out.println(catalogo.listarCatalogo(usuario.tienePermiso(Permiso.VER_FABRICANTE)));
            }
            mostrarMenu(usuario);
            int opcion = leerEntero(x, "Opción: ");

            // Además de ocultar opciones en el menú, cada caso vuelve a comprobar el permiso
            switch (opcion) {
                case 1:
                    if (permitido(usuario, Permiso.CONSULTAR_PRODUCTO)) {
                        consultarProducto(x, catalogo, usuario);
                    }
                    break;
                case 2:
                    if (permitido(usuario, Permiso.AGREGAR_PRODUCTO)) {
                        agregarProducto(x, catalogo);
                    }
                    break;
                case 3:
                    if (permitido(usuario, Permiso.ELIMINAR_PRODUCTO)) {
                        eliminarProducto(x, catalogo);
                    }
                    break;
                case 4:
                    if (permitido(usuario, Permiso.FACTURAR)) {
                        facturar(x, catalogo, gestor, usuario);
                    }
                    break;
                case 5:
                    if (permitido(usuario, Permiso.VER_FABRICANTE)) {
                        consultarFabricante(x, catalogo);
                    }
                    break;
                case 6:
                    if (permitido(usuario, Permiso.GESTIONAR_USUARIOS)) {
                        registrarUsuario(x, gestor);
                    }
                    break;
                case 7:
                    if (permitido(usuario, Permiso.GESTIONAR_USUARIOS)) {
                        gestionarPermisos(x, gestor);
                    }
                    break;
                case 8:
                    cambiarContrasena(x, usuario);
                    break;
                case 0:
                    sesionActiva = false;
                    System.out.println("Sesión cerrada.");
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    /**
     * Muestra solo las opciones que el usuario tiene permitidas.
     */
    private static void mostrarMenu(Usuario u) {
        System.out.println("¿Qué desea hacer?");
        if (u.tienePermiso(Permiso.CONSULTAR_PRODUCTO)) {
            System.out.println("1-Consultar producto por nombre");
        }
        if (u.tienePermiso(Permiso.AGREGAR_PRODUCTO)) {
            System.out.println("2-Agregar producto");
        }
        if (u.tienePermiso(Permiso.ELIMINAR_PRODUCTO)) {
            System.out.println("3-Eliminar producto");
        }
        if (u.tienePermiso(Permiso.FACTURAR)) {
            System.out.println("4-Facturar");
        }
        if (u.tienePermiso(Permiso.VER_FABRICANTE)) {
            System.out.println("5-Consultar fabricante de un producto");
        }
        if (u.tienePermiso(Permiso.GESTIONAR_USUARIOS)) {
            System.out.println("6-Registrar usuario");
            System.out.println("7-Gestionar permisos");
        }
        System.out.println("8-Cambiar mi contraseña");
        System.out.println("0-Cerrar sesión");
    }

    private static boolean permitido(Usuario u, Permiso permiso) {
        if (u.tienePermiso(permiso)) {
            return true;
        }
        System.out.println("Su rol no tiene permiso para esta acción.");
        return false;
    }

    // ---------------------------------------------------------------
    // Acciones sobre productos
    // ---------------------------------------------------------------

    private static void consultarProducto(Scanner x, Catalogo catalogo, Usuario usuario) {
        System.out.println("--- CONSULTAR PRODUCTO (escriba 0 para cancelar) ---");
        String texto = leerTexto(x, "Nombre (o parte del nombre) del producto: ");
        if (cancelo(texto)) {
            return;
        }
        List<Producto> resultados = catalogo.buscarPorTexto(texto);
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron productos que coincidan con \"" + texto + "\".");
            return;
        }
        boolean verFabricante = usuario.tienePermiso(Permiso.VER_FABRICANTE);
        for (Producto p : resultados) {
            System.out.println(p.darFicha(verFabricante));
        }
    }

    private static void consultarFabricante(Scanner x, Catalogo catalogo) {
        System.out.println("--- CONSULTAR FABRICANTE (escriba 0 para cancelar) ---");
        String texto = leerTexto(x, "Nombre (o parte del nombre) del producto: ");
        if (cancelo(texto)) {
            return;
        }
        List<Producto> resultados = catalogo.buscarPorTexto(texto);
        if (resultados.isEmpty()) {
            System.out.println("No se encontraron productos que coincidan con \"" + texto + "\".");
            return;
        }
        for (Producto p : resultados) {
            System.out.println("Producto: " + p.darNombre() + " (" + p.darId() + ")");
            System.out.println(p.darFabricante().darDescripcion());
        }
    }

    private static void agregarProducto(Scanner x, Catalogo catalogo) {
        System.out.println("--- AGREGAR PRODUCTO (escriba 0 para cancelar) ---");
        String nombre = leerTexto(x, "Nombre del producto: ");
        if (cancelo(nombre)) {
            return;
        }

        Producto existente = catalogo.buscarPorNombre(nombre);
        if (existente != null) {
            // El producto ya existe: en vez de duplicarlo, se le suma stock
            System.out.println("El producto \"" + existente.darNombre()
                    + "\" ya existe con el código " + existente.darId() + ".");
            int unidades = leerEntero(x, "¿Cuántas unidades desea sumarle? (0 para cancelar): ");
            if (cancelo(unidades)) {
                return;
            }
            existente.agregarCantidad(unidades);
            System.out.println("Stock actualizado: " + existente.darCantidad() + " unidades.");
            return;
        }

        int precio = leerEntero(x, "Precio unitario (0 para cancelar): ");
        if (cancelo(precio)) {
            return;
        }
        int cantidad = leerEntero(x, "Cantidad a agregar (0 para cancelar): ");
        if (cancelo(cantidad)) {
            return;
        }

        String nombreFabricante = leerTexto(x, "Nombre del fabricante: ");
        if (cancelo(nombreFabricante)) {
            return;
        }
        Fabricante fabricante = catalogo.buscarFabricante(nombreFabricante);
        if (fabricante == null) {
            System.out.println("Es un fabricante nuevo, complete sus datos.");
            String pais = leerTexto(x, "País del fabricante: ");
            if (cancelo(pais)) {
                return;
            }
            String contacto = leerTexto(x, "Contacto del fabricante (correo o teléfono): ");
            if (cancelo(contacto)) {
                return;
            }
            fabricante = new Fabricante(nombreFabricante, pais, contacto);
        } else {
            System.out.println("Se usará el fabricante ya registrado: " + fabricante.darNombre());
        }

        Producto nuevo = catalogo.agregarProducto(nombre, precio, cantidad, fabricante);
        System.out.println("Producto agregado con el código " + nuevo.darId());
    }

    private static void eliminarProducto(Scanner x, Catalogo catalogo) {
        System.out.println("--- ELIMINAR PRODUCTO (escriba 0 para cancelar) ---");
        String id = leerTexto(x, "Código del producto a eliminar: ");
        if (cancelo(id)) {
            return;
        }
        if (catalogo.eliminarProducto(id)) {
            System.out.println("El producto con el código " + id + " ha sido eliminado.");
        } else {
            System.out.println("No se encontró el producto con el código " + id);
        }
    }

    // ---------------------------------------------------------------
    // Facturación
    // ---------------------------------------------------------------

    private static void facturar(Scanner x, Catalogo catalogo, GestorUsuarios gestor, Usuario vendedor) {
        System.out.println("--- FACTURAR (escriba 0 para cancelar) ---");
        String documento = leerTexto(x, "Número de documento del cliente: ");
        if (cancelo(documento)) {
            return;
        }

        Cliente cliente = gestor.buscarClientePorIdentificacion(documento);
        if (cliente == null) {
            System.out.println("Ese cliente no está registrado.");
            if (!vendedor.tienePermiso(Permiso.REGISTRAR_CLIENTE)) {
                System.out.println("Su rol no puede registrar clientes. Pídale a un administrador que lo registre.");
                return;
            }
            String respuesta = leerTexto(x, "¿Desea registrarlo ahora? S/N: ");
            if (!respuesta.equalsIgnoreCase("s")) {
                return;
            }
            cliente = registrarCliente(x, gestor, documento);
            if (cliente == null) {
                return;
            }
        }

        Factura factura = new Factura(numeroFactura, LocalDate.now().toString(), cliente, vendedor);

        String otro = "s";
        while (otro.equalsIgnoreCase("s")) {
            String id = leerTexto(x, "Código del producto a facturar (0 para cancelar la factura): ");
            if (id.equals(CANCELAR)) {
                System.out.println("Factura cancelada. No se descontó ningún producto.");
                return;
            }

            Producto producto = catalogo.buscarPorId(id);
            if (producto == null) {
                System.out.println("No existe un producto con el código " + id);
            } else {
                int disponible = producto.darCantidad() - factura.cantidadFacturada(producto);
                if (disponible <= 0) {
                    System.out.println("No hay unidades disponibles de " + producto.darNombre());
                } else {
                    int cantidad = leerEntero(x, "Cantidad (disponibles: " + disponible
                            + ", 0 para no agregarlo): ");
                    if (cantidad > disponible) {
                        System.out.println("Solo hay " + disponible + " unidades disponibles.");
                    } else if (cantidad > 0) {
                        factura.agregarDetalle(new DetalleFactura(cantidad, producto));
                        System.out.println("Agregado: " + cantidad + " x " + producto.darNombre());
                    }
                }
            }
            otro = leerTexto(x, "¿Agregar otro producto a la factura? S/N: ");
        }

        if (factura.estaVacia()) {
            System.out.println("La factura no tiene productos, no se emitió.");
            return;
        }

        // Método de pago: se pide después de conocer el total
        double total = factura.calcularTotal();
        System.out.println("Total a pagar: $" + total);
        MetodoPago pago = pedirMetodoPago(x, total);
        if (pago == null || !factura.registrarPago(pago)) {
            System.out.println("Factura cancelada. No se descontó ningún producto.");
            return;
        }

        // Solo ahora, con la factura pagada, se descuenta el stock
        factura.descontarInventario();
        numeroFactura++;
        System.out.println("====== COMERCIALIZADORA AMAZONICA ======");
        System.out.println(factura.generarResumen());
        System.out.println("========================================");
    }

    /**
     * Pide el método de pago y devuelve un objeto de la subclase elegida
     * (Efectivo, Tarjeta o Transferencia), o null si se cancela.
     */
    private static MetodoPago pedirMetodoPago(Scanner x, double total) {
        while (true) {
            System.out.println("Método de pago:\n1-Efectivo\n2-Tarjeta\n3-Transferencia\n0-Cancelar factura");
            int opcion = leerEntero(x, "Opción: ");
            if (opcion == 0) {
                return null;
            }
            if (opcion == 1) {
                int recibido = leerEntero(x, "Monto recibido (0 para volver): ");
                if (recibido > 0) {
                    Efectivo efectivo = new Efectivo(recibido);
                    if (efectivo.cubreTotal(total)) {
                        return efectivo;
                    }
                    System.out.println("El monto recibido no alcanza para cubrir el total.");
                }
            } else if (opcion == 2) {
                int tipo = leerEntero(x, "Tipo de tarjeta (1-Débito, 2-Crédito, 0 para volver): ");
                if (tipo == 1 || tipo == 2) {
                    String digitos = leerTexto(x, "Últimos 4 dígitos de la tarjeta: ");
                    // matches("\\d{4}") comprueba que sean exactamente 4 números
                    if (digitos.matches("\\d{4}")) {
                        return new Tarjeta(tipo == 1 ? "débito" : "crédito", digitos);
                    }
                    System.out.println("Deben ser exactamente 4 números.");
                } else if (tipo != 0) {
                    System.out.println("Opción no válida.");
                }
            } else if (opcion == 3) {
                String referencia = leerTexto(x, "Número de referencia de la transferencia (0 para volver): ");
                if (!referencia.equals(CANCELAR)) {
                    return new Transferencia(referencia);
                }
            } else {
                System.out.println("Opción no válida.");
            }
        }
    }

    // ---------------------------------------------------------------
    // Usuarios, permisos y contraseña
    // ---------------------------------------------------------------

    /**
     * Registra un cliente nuevo desde el mostrador.
     * Su usuario y su contraseña inicial son su número de documento.
     * @return el cliente registrado, o null si se canceló o no se pudo.
     */
    private static Cliente registrarCliente(Scanner x, GestorUsuarios gestor, String documento) {
        String nombre = leerTexto(x, "Nombre del cliente (0 para cancelar): ");
        if (cancelo(nombre)) {
            return null;
        }
        String correo = leerTexto(x, "Correo del cliente (0 para cancelar): ");
        if (cancelo(correo)) {
            return null;
        }
        Cliente nuevo = new Cliente(nombre, documento, correo, documento, documento);
        if (!gestor.registrar(nuevo)) {
            System.out.println("Ya existe un usuario con el nombre de usuario " + documento + ".");
            return null;
        }
        System.out.println("Cliente registrado. Usuario: " + documento
                + " | Contraseña inicial: " + documento + " (puede cambiarla al iniciar sesión).");
        return nuevo;
    }

    private static void registrarUsuario(Scanner x, GestorUsuarios gestor) {
        System.out.println("--- REGISTRAR USUARIO (escriba 0 para cancelar) ---");
        System.out.println("Rol del nuevo usuario:\n1-Administrador\n2-Trabajador\n3-Cliente");
        int rol = leerEntero(x, "Rol (0 para cancelar): ");
        if (cancelo(rol)) {
            return;
        }
        if (rol > 3) {
            System.out.println("Rol no válido.");
            return;
        }

        String nombre = leerTexto(x, "Nombre completo: ");
        if (cancelo(nombre)) {
            return;
        }
        String nombreUsuario = leerTexto(x, "Nombre de usuario: ");
        if (cancelo(nombreUsuario)) {
            return;
        }
        String contrasena = leerTexto(x, "Contraseña: ");
        if (cancelo(contrasena)) {
            return;
        }

        Usuario nuevo;
        if (rol == 1) {
            nuevo = new Administrador(nombre, nombreUsuario, contrasena);
        } else if (rol == 2) {
            nuevo = new Trabajador(nombre, nombreUsuario, contrasena);
        } else {
            String documento = leerTexto(x, "Número de documento del cliente: ");
            if (cancelo(documento)) {
                return;
            }
            if (gestor.buscarClientePorIdentificacion(documento) != null) {
                System.out.println("Ya existe un cliente con ese documento.");
                return;
            }
            String correo = leerTexto(x, "Correo del cliente: ");
            if (cancelo(correo)) {
                return;
            }
            nuevo = new Cliente(nombre, documento, correo, nombreUsuario, contrasena);
        }

        if (gestor.registrar(nuevo)) {
            System.out.println("Usuario registrado: " + nuevo.darNombreUsuario() + " (" + nuevo.darRol() + ")");
        } else {
            System.out.println("Ya existe un usuario con ese nombre de usuario.");
        }
    }

    private static void gestionarPermisos(Scanner x, GestorUsuarios gestor) {
        System.out.println("--- GESTIONAR PERMISOS (escriba 0 para cancelar) ---");
        System.out.println(gestor.listarUsuarios());
        String nombreUsuario = leerTexto(x, "Usuario al que desea modificar: ");
        if (cancelo(nombreUsuario)) {
            return;
        }
        Usuario objetivo = gestor.buscarPorNombreUsuario(nombreUsuario);
        if (objetivo == null) {
            System.out.println("No existe el usuario " + nombreUsuario);
            return;
        }

        System.out.println("Permisos actuales de " + objetivo.darNombreUsuario() + ": " + objetivo.listarPermisos());
        System.out.println("1-Otorgar permiso\n2-Quitar permiso");
        int accion = leerEntero(x, "Opción (0 para cancelar): ");
        if (cancelo(accion)) {
            return;
        }
        if (accion != 1 && accion != 2) {
            System.out.println("Opción no válida.");
            return;
        }

        Permiso[] todos = Permiso.values();
        for (int i = 0; i < todos.length; i++) {
            System.out.println((i + 1) + "-" + todos[i].darDescripcion());
        }
        int numero = leerEntero(x, "Permiso (0 para cancelar): ");
        if (cancelo(numero)) {
            return;
        }
        if (numero > todos.length) {
            System.out.println("Permiso no válido.");
            return;
        }
        Permiso elegido = todos[numero - 1];

        if (accion == 1) {
            if (objetivo.tienePermiso(elegido)) {
                System.out.println("Ese usuario ya tiene ese permiso.");
            } else if (objetivo.otorgarPermiso(elegido)) {
                System.out.println("Permiso otorgado.");
            } else {
                System.out.println("Ese permiso no se le puede otorgar a un " + objetivo.darRol() + ".");
            }
        } else {
            if (!objetivo.tienePermiso(elegido)) {
                System.out.println("Ese usuario no tiene ese permiso.");
            } else if (objetivo.revocarPermiso(elegido)) {
                System.out.println("Permiso quitado.");
            } else {
                System.out.println("No se le puede quitar ese permiso a un " + objetivo.darRol() + ".");
            }
        }
    }

    private static void cambiarContrasena(Scanner x, Usuario usuario) {
        System.out.println("--- CAMBIAR CONTRASEÑA (escriba 0 para cancelar) ---");
        String actual = leerTexto(x, "Contraseña actual: ");
        if (cancelo(actual)) {
            return;
        }
        String nueva = leerTexto(x, "Contraseña nueva: ");
        if (cancelo(nueva)) {
            return;
        }
        if (usuario.cambiarContrasena(actual, nueva)) {
            System.out.println("Contraseña actualizada.");
        } else {
            System.out.println("La contraseña actual no es correcta.");
        }
    }

    // ---------------------------------------------------------------
    // Cancelar y lectura de datos con validación
    // ---------------------------------------------------------------

    /**
     * Si el texto es la palabra de cancelar, avisa y devuelve true.
     */
    private static boolean cancelo(String valor) {
        if (valor.equals(CANCELAR)) {
            System.out.println("Acción cancelada.");
            return true;
        }
        return false;
    }

    /**
     * Igual que el anterior pero para números: el 0 cancela.
     */
    private static boolean cancelo(int valor) {
        if (valor == 0) {
            System.out.println("Acción cancelada.");
            return true;
        }
        return false;
    }

    /**
     * Pide un número entero mayor o igual a 0 y repite hasta que sea válido.
     */
    private static int leerEntero(Scanner x, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String linea = x.nextLine().trim();
            try {
                int numero = Integer.parseInt(linea);
                if (numero >= 0) {
                    return numero;
                }
                System.out.println("Digite un número entero mayor o igual a 0.");
            } catch (NumberFormatException e) {
                System.out.println("Digite un número entero válido.");
            }
        }
    }

    /**
     * Pide un texto y repite hasta que no esté vacío.
     */
    private static String leerTexto(Scanner x, String mensaje) {
        while (true) {
            System.out.print(mensaje);
            String linea = x.nextLine().trim();
            if (!linea.isEmpty()) {
                return linea;
            }
            System.out.println("Este dato no puede estar vacío.");
        }
    }
}