/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

import java.util.ArrayList;

/**
 * Guarda los usuarios del sistema y se encarga del inicio de sesión.
 */
public class GestorUsuarios {

    private ArrayList<Usuario> usuarios;

    public GestorUsuarios() {
        usuarios = new ArrayList<Usuario>();

        // Usuarios de ejemplo para probar (cámbialos cuando quieras):
        registrar(new Administrador("Dueño", "admin", "admin123"));
        registrar(new Trabajador("Trabajador de ejemplo", "trabajador", "trab123"));
        registrar(new Cliente("Cliente de ejemplo", "1000", "cliente@correo.com", "cliente", "cli123"));
    }

    /**
     * Agrega un usuario si su nombre de usuario no está repetido.
     * @return true si se registró, false si ya existía ese nombre de usuario.
     */
    public boolean registrar(Usuario nuevo) {
        if (buscarPorNombreUsuario(nuevo.darNombreUsuario()) != null) {
            return false;
        }
        usuarios.add(nuevo);
        return true;
    }

    /**
     * Valida usuario y contraseña.
     * @return el usuario (ya como Administrador, Trabajador o Cliente) o null si los datos no coinciden.
     */
    public Usuario iniciarSesion(String nombreUsuario, String contrasena) {
        Usuario u = buscarPorNombreUsuario(nombreUsuario);
        if (u != null && u.validarContrasena(contrasena)) {
            return u;
        }
        return null;
    }

    public Usuario buscarPorNombreUsuario(String nombreUsuario) {
        for (Usuario u : usuarios) {
            if (u.darNombreUsuario().equalsIgnoreCase(nombreUsuario.trim())) {
                return u;
            }
        }
        return null;
    }

    /**
     * Busca entre los usuarios que son Cliente el que tenga ese documento.
     */
    public Cliente buscarClientePorIdentificacion(String identificacion) {
        for (Usuario u : usuarios) {
            if (u instanceof Cliente) {
                Cliente c = (Cliente) u;
                if (c.darIdentificacion().equalsIgnoreCase(identificacion.trim())) {
                    return c;
                }
            }
        }
        return null;
    }

    public String listarUsuarios() {
        String texto = "--- USUARIOS ---\n";
        for (Usuario u : usuarios) {
            texto += u.darNombreUsuario() + " | " + u.darRol() + " | " + u.darNombre() + "\n";
        }
        return texto;
    }
}