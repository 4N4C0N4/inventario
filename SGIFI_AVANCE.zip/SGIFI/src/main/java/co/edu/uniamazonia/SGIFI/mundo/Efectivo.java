/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Pago en efectivo: guarda lo recibido y calcula el cambio.
 */
public class Efectivo extends MetodoPago {

    private double montoRecibido;

    public Efectivo(double montoRecibido) {
        super("Efectivo");
        this.montoRecibido = montoRecibido;
    }

    @Override
    public boolean cubreTotal(double total) {
        return this.montoRecibido >= total;
    }

    @Override
    public String describir(double total) {
        return "Método de pago: Efectivo\n"
                + "Recibido: $" + this.montoRecibido + "\n"
                + "Cambio: $" + (this.montoRecibido - total) + "\n";
    }
}