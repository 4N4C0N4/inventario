/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Pago por transferencia: guarda el número de referencia del comprobante.
 */
public class Transferencia extends MetodoPago {

    private String referencia;

    public Transferencia(String referencia) {
        super("Transferencia");
        this.referencia = referencia;
    }

    @Override
    public boolean cubreTotal(double total) {
        return true;
    }

    @Override
    public String describir(double total) {
        return "Método de pago: Transferencia (referencia " + this.referencia + ")\n";
    }
}