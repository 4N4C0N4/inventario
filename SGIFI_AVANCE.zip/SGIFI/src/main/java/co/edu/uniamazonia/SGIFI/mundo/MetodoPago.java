/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.uniamazonia.SGIFI.mundo;

/**
 * Forma en que se paga una factura. Es abstracta: cada forma de pago
 * (Efectivo, Tarjeta, Transferencia) guarda sus propios datos y define
 * cómo se valida y cómo se describe en la factura.
 */
public abstract class MetodoPago {

    private String nombre;

    public MetodoPago(String nombre) {
        this.nombre = nombre;
    }

    public String darNombre() {
        return this.nombre;
    }

    /**
     * Indica si este pago alcanza para cubrir el total de la factura.
     */
    public abstract boolean cubreTotal(double total);

    /**
     * Texto que aparece en la factura sobre este pago.
     */
    public abstract String describir(double total);
}