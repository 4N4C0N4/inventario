/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.inventario;

import java.util.Scanner;

/**
 *
 * @author isnel
 */
// objetivos
//agregar producto, eleminar producto, factuar,
public class Inventario {

    public static void main(String[] args) {
      Scanner x = new Scanner(System.in);
       catalogo listav = new catalogo();
        
        listav.agregarProducto(new Producto("laptop", "001", 750));
        listav.agregarProducto(new Producto("mouse", "002", 25));
        x.nextLine();
        String opcion1 = "s";
        while(opcion1.equalsIgnoreCase("s")){
             System.out.println("Que desea hacer: " + "\n1-Agregar producto" + "\n2-Eliminar producto" + "\n3-facturar" );
        int opcion2 = x.nextInt();
        switch(opcion2){
            case 1:
                System.out.println("Nombre del producto");
                String nombrepn = x.nextLine();
                System.out.println("Id del producto");
                String idpn = x.nextLine();
                System.out.println("Precio unitario del producto");
                int precioupn = x.nextInt();
                x.nextLine();
                listav.agregarProducto(new Producto(nombrepn, idpn, precioupn));
                System.out.println("Producto agregado");
                System.out.println("desea hace otra accion: S/N");
                opcion1 = x.nextLine();
                listav.mostrarCatalogo();
                break;
            case 2:
                break;
            case 3:
                
        // 1. Instanciar el cliente
        Cliente cliente = new Cliente("11223344", "Maria Caicedo", "m.caicedo@uniamazonia.edu.co");

        // 2. Instanciar productos agroecológicos
        Producto p1 = new Producto("P001", "Pulpa de Araza 500g", 8500);
        Producto p2 = new Producto("P002", "Queso Caqueteno 1kg", 24000);

        // 3. Crear la factura contenedora
        Factura factura = new Factura(1001, "2026-09-18", cliente);

        // 4. Crear los detalles y agregarlos
        DetalleFactura d1 = new DetalleFactura(3, p1); // 3 pulpas de arazá
        DetalleFactura d2 = new DetalleFactura(2, p2); // 2 kg de queso

        factura.agregarDetalle(d1);
        factura.agregarDetalle(d2);

        // 5. Calcular el total acumulado
        double totalFactura = factura.calcularTotal();

        // 6. Imprimir comprobante
        System.out.println("====== COMERCIALIZADORA AMAZONICA ======");
        System.out.println("Factura N: " + factura.darNumeroFactura());
        System.out.println("Cliente: " + factura.darCliente().darNombre());
        factura.mostrarDetalles();
        //System.out.println("items registrados: " + factura.darDetalles().size());
        System.out.println("Total a pagar: $" + totalFactura);
        System.out.println("========================================");
        break;
    }
}
      listav.mostrarCatalogo();          
        }
        }
        
    

