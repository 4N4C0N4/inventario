/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

/**
 *
 * @author isnel
 */
public class Cliente {
    
    private String nombre;
    private String identificacion;
    private String correo;

    public Cliente(String nombre, String identificacion, String correo) {
        this.nombre = nombre;
        this.identificacion = identificacion;
        this.correo = correo;
    }
    public String darNombre(){
        return this.nombre;
    }
    public String darIdentidentificacion(){
        return this.identificacion;
    }
    public String darCorreo(){
        return this.correo;
    }
}
