/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

/**
 *
 * @author isnel
 */
public class DetalleFactura {
        
    private int cantidad;
    private double subtotal;

    // Asociación simple 1 a 1 hacia Producto (Atributo de tipo Objeto)
    private Producto producto;

    public DetalleFactura(int cantidad, Producto producto) {
        this.cantidad = cantidad;
        this.producto = producto;
        this.subtotal = calcularSubtotal();
    }

    /**
     * Calcula el subtotal multiplicando la cantidad por el precio unitario del producto.
     * @return 
     */
    public double calcularSubtotal() {
        if (this.producto != null) {
            this.subtotal = this.cantidad * this.producto.darPreciou();
        } else {
            this.subtotal = 0.0;
        }
        return this.subtotal;
    }

    public int darCantidad() {
        return this.cantidad;
    }

    public double darSubtotal() {
        return this.subtotal;
    }

    public Producto darProducto() {
        return this.producto;
    }
}

    
    
    


