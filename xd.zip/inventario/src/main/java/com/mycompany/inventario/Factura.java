/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

import java.util.ArrayList;

/**
 *
 * @author isnel
 */
public class Factura {

    private int numeroFactura;
    private String fecha;
    private double total;

    // Asociación simple 1 a 1 hacia Cliente
    private Cliente cliente;

    // Relación 1 a Muchos hacia DetalleFactura gestionada mediante ArrayList
    private ArrayList<DetalleFactura> detalles;

    public Factura(int numeroFactura, String fecha, Cliente cliente) {
        this.numeroFactura = numeroFactura;
        this.fecha = fecha;
        this.cliente = cliente;

        // Instanciación obligatoria del ArrayList para obtener la instancia real en memoria
        this.detalles = new ArrayList<DetalleFactura>();
        this.total = 0.0;
    }

    /**
     * Agrega un nuevo renglón de detalle a la colección dinámica mediante .add()
     */
    public void agregarDetalle(DetalleFactura detalle) {
        if (detalle != null) {
            this.detalles.add(detalle);
        }
    }

    /**
     * Recorre la colección dinámica con .size() y .get(i) para acumular el total.
     * Cadena conceptual: Factura -> ArrayList -> DetalleFactura -> Producto -> darPrecioUnitario()
     */
    public double calcularTotal() {
        double acumulado = 0.0;
        for (int i = 0; i < this.detalles.size(); i++) {
            DetalleFactura det = this.detalles.get(i);
            acumulado += det.calcularSubtotal();
        }
        this.total = acumulado;
        return this.total;
    }

    public int darNumeroFactura() {
        return this.numeroFactura;
    }

    public String darFecha() {
        return this.fecha;
    }

    public Cliente darCliente() {
        return this.cliente;
    }
    public void mostrarDetalles() {
        for (DetalleFactura detalle : detalles) {    
            
            System.out.println( detalle.darCantidad() + " - " + detalle.darProducto().darNombre() + " - " + detalle.darSubtotal());   
        }
    }
    public ArrayList<DetalleFactura> darDetalles() {
        return this.detalles;
    }
}