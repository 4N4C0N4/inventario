/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

import java.util.ArrayList;
import java.util.List;
public class catalogo {

    private List<Producto> listaProductos;

    public catalogo() {
        listaProductos = new ArrayList<>();
    }

    public void agregarProducto(Producto p) {
        listaProductos.add(p);
    }

    public void mostrarCatalogo() {
        System.out.println("--- CATÁLOGO DE PRODUCTOS ---");
        for (Producto p : listaProductos) {
            p.mostrarDetalles();
        }
    }
}

