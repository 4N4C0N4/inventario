/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

/**
 *
 * @author isnel
 */
public class Producto {
  private String nombre;
  private String id;
  private int preciou; 

    public Producto(String nombre, String id, int preciou) {
        this.nombre = nombre;
        this.id = id;
        this.preciou = preciou;

    }
  public String darNombre(){
       return this.nombre;
      
  }
  public String darId(){
      return this.id;
  }
  public int darPreciou(){
      return this.preciou;
  }

  public void mostrarDetalles(){
      System.out.println("nombre: " + nombre + "\nid: " + id + "\nPrecio Unitario: " + preciou);
  }
}
