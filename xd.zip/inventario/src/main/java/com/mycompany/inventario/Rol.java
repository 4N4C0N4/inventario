/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.inventario;

/**
 *
 * @author isnel
 */
public class Rol {
    private String nombreRol;
    private String permisos;
    private String descripcion;
    
    public void verificarPermisos(){
        
    }
    public void verInventario(){
        
    }

    public Rol(String nombreRol, String permisos, String descripcion) {
        this.nombreRol = nombreRol;
        this.permisos = permisos;
        this.descripcion = descripcion;
    }
}
